package h;

import android.widget.ArrayAdapter;

/* renamed from: h.g  reason: case insensitive filesystem */
public final class C0116g extends ArrayAdapter {
    public final long getItemId(int i) {
        return (long) i;
    }

    public final boolean hasStableIds() {
        return true;
    }
}
