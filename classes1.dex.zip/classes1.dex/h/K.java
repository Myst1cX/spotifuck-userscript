package h;

public final class K {

    /* renamed from: a  reason: collision with root package name */
    public boolean f2916a;

    /* renamed from: b  reason: collision with root package name */
    public long f2917b;
}
