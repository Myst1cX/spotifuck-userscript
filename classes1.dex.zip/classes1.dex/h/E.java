package h;

import N.C0011k;
import android.view.KeyEvent;

public final /* synthetic */ class E implements C0011k {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C0118i f2900f;

    public /* synthetic */ E(C0118i iVar) {
        this.f2900f = iVar;
    }

    public final boolean e(KeyEvent keyEvent) {
        return this.f2900f.j(keyEvent);
    }
}
