package h;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import g0.j;
import n.C0198m;

/* renamed from: h.f  reason: case insensitive filesystem */
public final class C0115f {

    /* renamed from: a  reason: collision with root package name */
    public final ContextThemeWrapper f2962a;

    /* renamed from: b  reason: collision with root package name */
    public final LayoutInflater f2963b;

    /* renamed from: c  reason: collision with root package name */
    public Drawable f2964c;

    /* renamed from: d  reason: collision with root package name */
    public CharSequence f2965d;
    public View e;

    /* renamed from: f  reason: collision with root package name */
    public CharSequence f2966f;

    /* renamed from: g  reason: collision with root package name */
    public CharSequence f2967g;

    /* renamed from: h  reason: collision with root package name */
    public DialogInterface.OnClickListener f2968h;
    public CharSequence i;

    /* renamed from: j  reason: collision with root package name */
    public DialogInterface.OnClickListener f2969j;

    /* renamed from: k  reason: collision with root package name */
    public C0198m f2970k;

    /* renamed from: l  reason: collision with root package name */
    public CharSequence[] f2971l;

    /* renamed from: m  reason: collision with root package name */
    public Object f2972m;

    /* renamed from: n  reason: collision with root package name */
    public DialogInterface.OnClickListener f2973n;

    /* renamed from: o  reason: collision with root package name */
    public View f2974o;

    /* renamed from: p  reason: collision with root package name */
    public boolean[] f2975p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f2976q;

    /* renamed from: r  reason: collision with root package name */
    public boolean f2977r;

    /* renamed from: s  reason: collision with root package name */
    public int f2978s = -1;

    /* renamed from: t  reason: collision with root package name */
    public j f2979t;

    public C0115f(ContextThemeWrapper contextThemeWrapper) {
        this.f2962a = contextThemeWrapper;
        this.f2963b = (LayoutInflater) contextThemeWrapper.getSystemService("layout_inflater");
    }
}
