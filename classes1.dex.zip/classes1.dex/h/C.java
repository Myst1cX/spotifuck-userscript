package h;

import android.os.Bundle;
import android.view.View;
import m.C0176c;
import n.C0193h;
import n.C0197l;

public final class C {

    /* renamed from: a  reason: collision with root package name */
    public int f2834a;

    /* renamed from: b  reason: collision with root package name */
    public int f2835b;

    /* renamed from: c  reason: collision with root package name */
    public int f2836c;

    /* renamed from: d  reason: collision with root package name */
    public int f2837d;
    public B e;

    /* renamed from: f  reason: collision with root package name */
    public View f2838f;

    /* renamed from: g  reason: collision with root package name */
    public View f2839g;

    /* renamed from: h  reason: collision with root package name */
    public C0197l f2840h;
    public C0193h i;

    /* renamed from: j  reason: collision with root package name */
    public C0176c f2841j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f2842k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f2843l;

    /* renamed from: m  reason: collision with root package name */
    public boolean f2844m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f2845n;

    /* renamed from: o  reason: collision with root package name */
    public boolean f2846o;

    /* renamed from: p  reason: collision with root package name */
    public Bundle f2847p;
}
