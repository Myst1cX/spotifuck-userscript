package h;

import android.app.Service;

public abstract class I extends Service {

    /* renamed from: f  reason: collision with root package name */
    public static final /* synthetic */ int f2911f = 0;
}
