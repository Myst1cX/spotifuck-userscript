package h;

import android.os.LocaleList;

public abstract class o {
    public static LocaleList a(String str) {
        return LocaleList.forLanguageTags(str);
    }
}
