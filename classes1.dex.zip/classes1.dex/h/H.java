package h;

public abstract class H {
    public static int a() {
        return 512;
    }
}
