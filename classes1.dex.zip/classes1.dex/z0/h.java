package Z0;

public abstract class h {
}
