package Z0;

public interface a {
    Class a();
}
