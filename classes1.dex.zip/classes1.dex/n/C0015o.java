package N;

import android.view.View;

/* renamed from: N.o  reason: case insensitive filesystem */
public interface C0015o {
    void a(View view, View view2, int i, int i2);

    void c(View view, int i, int i2, int i3, int i4, int i5);

    void d(View view, int i);

    void e(View view, int i, int i2, int[] iArr, int i3);

    boolean f(View view, View view2, int i, int i2);
}
