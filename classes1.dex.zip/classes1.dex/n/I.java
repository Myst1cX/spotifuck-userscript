package N;

import android.view.KeyEvent;
import android.view.View;

public final /* synthetic */ class I implements View.OnUnhandledKeyEventListener {
    public final boolean onUnhandledKeyEvent(View view, KeyEvent keyEvent) {
        throw null;
    }
}
