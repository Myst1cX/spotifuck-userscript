package n;

/* renamed from: n.y  reason: case insensitive filesystem */
public interface C0210y {
    void a(C0199n nVar);

    C0199n getItemData();
}
