package n;

import android.view.MenuItem;

/* renamed from: n.j  reason: case insensitive filesystem */
public interface C0195j {
    boolean d(C0197l lVar, MenuItem menuItem);

    void f(C0197l lVar);
}
