package n;

import android.content.Context;

/* renamed from: n.x  reason: case insensitive filesystem */
public interface C0209x {
    void b(C0197l lVar, boolean z2);

    void c();

    boolean d(C0199n nVar);

    void f(Context context, C0197l lVar);

    boolean g(C0185D d2);

    boolean h();

    void j(C0208w wVar);

    boolean k(C0199n nVar);
}
