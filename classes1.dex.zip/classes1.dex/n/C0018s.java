package N;

/* renamed from: N.s  reason: case insensitive filesystem */
public interface C0018s {
}
