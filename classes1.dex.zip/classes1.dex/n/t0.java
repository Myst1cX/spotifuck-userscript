package N;

import F.c;
import android.view.View;
import android.view.WindowInsets;

public final class t0 extends s0 {

    /* renamed from: q  reason: collision with root package name */
    public static final w0 f590q = w0.g((View) null, WindowInsets.CONSUMED);

    public final void d(View view) {
    }

    public c f(int i) {
        return c.c(this.f580c.getInsets(v0.a(i)));
    }

    public t0(w0 w0Var, WindowInsets windowInsets) {
        super(w0Var, windowInsets);
    }
}
