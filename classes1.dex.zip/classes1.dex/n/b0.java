package N;

import android.view.Window;

public abstract class b0 {
    public static void a(Window window, boolean z2) {
        window.setDecorFitsSystemWindows(z2);
    }
}
