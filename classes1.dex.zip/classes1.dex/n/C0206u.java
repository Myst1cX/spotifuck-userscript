package n;

import android.widget.PopupWindow;

/* renamed from: n.u  reason: case insensitive filesystem */
public final class C0206u implements PopupWindow.OnDismissListener {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ C0207v f3935f;

    public final void onDismiss() {
        this.f3935f.c();
    }

    public C0206u(C0207v vVar) {
        this.f3935f = vVar;
    }
}
