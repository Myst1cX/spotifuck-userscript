package N;

public interface O {
}
