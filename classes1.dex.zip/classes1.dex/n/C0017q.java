package N;

import android.view.View;
import j0.a0;

/* renamed from: N.q  reason: case insensitive filesystem */
public final class C0017q {

    /* renamed from: a  reason: collision with root package name */
    public int f584a;

    /* renamed from: b  reason: collision with root package name */
    public int f585b;

    public void a(a0 a0Var) {
        View view = a0Var.f3338a;
        this.f584a = view.getLeft();
        this.f585b = view.getTop();
        view.getRight();
        view.getBottom();
    }
}
