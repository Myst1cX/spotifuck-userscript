package n;

/* renamed from: n.w  reason: case insensitive filesystem */
public interface C0208w {
    void b(C0197l lVar, boolean z2);

    boolean h(C0197l lVar);
}
