package N;

import F.c;

public final class n0 extends m0 {
    public n0() {
    }

    public n0(w0 w0Var) {
        super(w0Var);
    }

    public void c(int i, c cVar) {
        this.f569c.setInsets(v0.a(i), cVar.d());
    }
}
