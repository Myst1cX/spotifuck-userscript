package n;

/* renamed from: n.k  reason: case insensitive filesystem */
public interface C0196k {
    boolean c(C0199n nVar);
}
