package n;

import o.C0309v0;

/* renamed from: n.B  reason: case insensitive filesystem */
public interface C0183B {
    boolean a();

    void dismiss();

    C0309v0 e();

    void i();
}
