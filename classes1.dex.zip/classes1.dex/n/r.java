package N;

import android.view.View;

public interface r {
    w0 l(View view, w0 w0Var);
}
