package N;

/* renamed from: N.f  reason: case insensitive filesystem */
public final class C0006f {

    /* renamed from: a  reason: collision with root package name */
    public final C0005e f539a;

    public final String toString() {
        return this.f539a.toString();
    }

    public C0006f(C0005e eVar) {
        this.f539a = eVar;
    }
}
