package n;

/* renamed from: n.z  reason: case insensitive filesystem */
public interface C0211z {
    void b(C0197l lVar);
}
