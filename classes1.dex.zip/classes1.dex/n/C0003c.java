package N;

import android.net.Uri;
import android.os.Bundle;

/* renamed from: N.c  reason: case insensitive filesystem */
public interface C0003c {
    void b(Bundle bundle);

    void d(Uri uri);

    C0006f j();

    void p(int i);
}
