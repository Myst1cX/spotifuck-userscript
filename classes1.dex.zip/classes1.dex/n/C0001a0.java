package N;

/* renamed from: N.a0  reason: case insensitive filesystem */
public interface C0001a0 {
    void a();

    void b();

    void c();
}
