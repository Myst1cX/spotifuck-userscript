package N;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/* renamed from: N.x  reason: case insensitive filesystem */
public abstract class C0023x {

    /* renamed from: a  reason: collision with root package name */
    public static final Map f598a = Collections.synchronizedMap(new WeakHashMap());
}
