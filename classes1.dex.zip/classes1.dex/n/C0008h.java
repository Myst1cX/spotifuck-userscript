package N;

import A.b;
import android.content.Context;
import android.view.VelocityTracker;

/* renamed from: N.h  reason: case insensitive filesystem */
public final class C0008h {

    /* renamed from: a  reason: collision with root package name */
    public final Context f547a;

    /* renamed from: b  reason: collision with root package name */
    public final b f548b;

    /* renamed from: c  reason: collision with root package name */
    public VelocityTracker f549c;

    /* renamed from: d  reason: collision with root package name */
    public float f550d;
    public int e = -1;

    /* renamed from: f  reason: collision with root package name */
    public int f551f = -1;

    /* renamed from: g  reason: collision with root package name */
    public int f552g = -1;

    /* renamed from: h  reason: collision with root package name */
    public final int[] f553h = {Integer.MAX_VALUE, 0};

    public C0008h(Context context, b bVar) {
        this.f547a = context;
        this.f548b = bVar;
    }
}
