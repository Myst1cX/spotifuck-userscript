package N;

import android.view.View;

/* renamed from: N.p  reason: case insensitive filesystem */
public interface C0016p extends C0015o {
    void b(View view, int i, int i2, int i3, int i4, int i5, int[] iArr);
}
