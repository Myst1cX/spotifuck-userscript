package N;

/* renamed from: N.t  reason: case insensitive filesystem */
public interface C0019t {
    C0006f a(C0006f fVar);
}
