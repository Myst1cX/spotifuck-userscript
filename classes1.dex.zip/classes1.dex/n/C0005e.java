package N;

import android.content.ClipData;
import android.view.ContentInfo;

/* renamed from: N.e  reason: case insensitive filesystem */
public interface C0005e {
    int a();

    int f();

    ClipData i();

    ContentInfo n();
}
