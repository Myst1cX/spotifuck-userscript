package N;

import android.view.KeyEvent;

/* renamed from: N.k  reason: case insensitive filesystem */
public interface C0011k {
    boolean e(KeyEvent keyEvent);
}
