package N;

/* renamed from: N.z  reason: case insensitive filesystem */
public final /* synthetic */ class C0025z implements C0019t {
    public final C0006f a(C0006f fVar) {
        return fVar;
    }
}
