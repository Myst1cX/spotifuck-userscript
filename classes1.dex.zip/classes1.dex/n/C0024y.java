package N;

/* renamed from: N.y  reason: case insensitive filesystem */
public final class C0024y {

    /* renamed from: a  reason: collision with root package name */
    public final float[] f600a = new float[20];

    /* renamed from: b  reason: collision with root package name */
    public final long[] f601b = new long[20];

    /* renamed from: c  reason: collision with root package name */
    public float f602c = 0.0f;

    /* renamed from: d  reason: collision with root package name */
    public int f603d = 0;
    public int e = 0;
}
