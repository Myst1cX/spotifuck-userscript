package n;

import o.M0;

/* renamed from: n.e  reason: case insensitive filesystem */
public final class C0190e {

    /* renamed from: a  reason: collision with root package name */
    public final M0 f3832a;

    /* renamed from: b  reason: collision with root package name */
    public final C0197l f3833b;

    /* renamed from: c  reason: collision with root package name */
    public final int f3834c;

    public C0190e(M0 m0, C0197l lVar, int i) {
        this.f3832a = m0;
        this.f3833b = lVar;
        this.f3834c = i;
    }
}
