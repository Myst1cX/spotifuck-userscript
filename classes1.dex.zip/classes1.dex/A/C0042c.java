package a;

/* renamed from: a.c  reason: case insensitive filesystem */
public final class C0042c {

    /* renamed from: a  reason: collision with root package name */
    public final int f1022a;

    /* renamed from: b  reason: collision with root package name */
    public final String f1023b;

    /* renamed from: c  reason: collision with root package name */
    public final int f1024c;

    /* renamed from: d  reason: collision with root package name */
    public final int f1025d;

    public C0042c(String str, int i, int i2) {
        this.f1023b = str;
        this.f1022a = i;
        this.f1024c = i2;
        this.f1025d = -1;
    }

    public C0042c(String str, int i) {
        this.f1023b = str;
        this.f1022a = i;
        this.f1024c = 3;
        this.f1025d = 4;
    }
}
