package q1;

import java.security.cert.X509Certificate;

public interface d {
    X509Certificate a(X509Certificate x509Certificate);
}
