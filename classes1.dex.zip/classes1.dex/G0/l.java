package g0;

import T.k;
import android.os.Parcel;
import android.os.Parcelable;
import android.view.AbsSavedState;

public class l extends AbsSavedState {
    public static final Parcelable.Creator<l> CREATOR = new k(18);

    public l(Parcel parcel) {
        super(parcel);
    }
}
