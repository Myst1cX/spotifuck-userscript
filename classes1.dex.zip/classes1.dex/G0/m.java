package g0;

import androidx.preference.Preference;

public interface m {
    void a(Preference preference);
}
