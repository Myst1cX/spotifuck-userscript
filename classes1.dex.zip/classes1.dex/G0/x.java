package g0;

import E0.a;
import N.C0002b;
import androidx.recyclerview.widget.RecyclerView;
import j0.b0;
import j0.c0;

public final class x extends c0 {

    /* renamed from: f  reason: collision with root package name */
    public final RecyclerView f2613f;

    /* renamed from: g  reason: collision with root package name */
    public final b0 f2614g = this.e;

    /* renamed from: h  reason: collision with root package name */
    public final a f2615h = new a(3, this);

    public final C0002b j() {
        return this.f2615h;
    }

    public x(RecyclerView recyclerView) {
        super(recyclerView);
        this.f2613f = recyclerView;
    }
}
