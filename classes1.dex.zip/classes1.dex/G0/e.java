package g0;

import androidx.preference.Preference;

public final class e extends Preference {

    /* renamed from: M  reason: collision with root package name */
    public long f2558M;

    public final long c() {
        return this.f2558M;
    }

    public final void k(y yVar) {
        super.k(yVar);
        yVar.f2619w = false;
    }
}
