package k1;

import g1.A;
import g1.B;
import g1.C;
import g1.D;
import r1.u;

public interface b {
    u a(A a2, long j2);

    void b(A a2);

    void c();

    void d();

    D e(C c2);

    B f(boolean z2);
}
