package v;

import java.util.ArrayList;

/* renamed from: v.b  reason: case insensitive filesystem */
public final class C0345b {

    /* renamed from: a  reason: collision with root package name */
    public final C0347d f4686a;

    /* renamed from: b  reason: collision with root package name */
    public C0347d f4687b;

    /* renamed from: c  reason: collision with root package name */
    public C0347d f4688c;

    /* renamed from: d  reason: collision with root package name */
    public C0347d f4689d;
    public C0347d e;

    /* renamed from: f  reason: collision with root package name */
    public C0347d f4690f;

    /* renamed from: g  reason: collision with root package name */
    public C0347d f4691g;

    /* renamed from: h  reason: collision with root package name */
    public ArrayList f4692h;
    public int i;

    /* renamed from: j  reason: collision with root package name */
    public int f4693j;

    /* renamed from: k  reason: collision with root package name */
    public float f4694k = 0.0f;

    /* renamed from: l  reason: collision with root package name */
    public final int f4695l;

    /* renamed from: m  reason: collision with root package name */
    public final boolean f4696m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f4697n;

    /* renamed from: o  reason: collision with root package name */
    public boolean f4698o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f4699p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f4700q;

    public C0345b(C0347d dVar, int i2, boolean z2) {
        this.f4686a = dVar;
        this.f4695l = i2;
        this.f4696m = z2;
    }
}
