package G;

public interface g {
}
