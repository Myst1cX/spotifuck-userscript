package G;

public interface h {
}
