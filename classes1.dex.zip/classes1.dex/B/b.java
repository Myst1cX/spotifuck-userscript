package b;

import android.os.Bundle;
import android.os.IInterface;

public interface b extends IInterface {

    /* renamed from: a  reason: collision with root package name */
    public static final String f2071a = "android$support$v4$os$IResultReceiver".replace('$', '.');

    void T(int i, Bundle bundle);
}
