package B;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f26a = {16843173, 16843551, 16844359, 2130968628, 2130969232};

    /* renamed from: b  reason: collision with root package name */
    public static final int[] f27b = {2130969113, 2130969114, 2130969115, 2130969116, 2130969117, 2130969118, 2130969119};

    /* renamed from: c  reason: collision with root package name */
    public static final int[] f28c = {16844082, 16844083, 16844095, 16844143, 16844144, 2130969111, 2130969120, 2130969121, 2130969122, 2130969871};

    /* renamed from: d  reason: collision with root package name */
    public static final int[] f29d = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
    public static final int[] e = {16843173, 16844052};
}
