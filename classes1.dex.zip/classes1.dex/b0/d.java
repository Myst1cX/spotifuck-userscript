package b0;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public final Class f2077a;

    public d(Class cls) {
        this.f2077a = cls;
    }
}
