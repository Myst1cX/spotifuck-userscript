package b0;

public final class c extends b {
    public /* synthetic */ c(int i) {
        this((b) C0084a.f2075b);
    }

    public c(b bVar) {
        Z0.c.e("initialExtras", bVar);
        this.f2076a.putAll(bVar.f2076a);
    }
}
