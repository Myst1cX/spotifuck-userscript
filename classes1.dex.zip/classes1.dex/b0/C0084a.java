package b0;

/* renamed from: b0.a  reason: case insensitive filesystem */
public final class C0084a extends b {

    /* renamed from: b  reason: collision with root package name */
    public static final C0084a f2075b = new b();
}
