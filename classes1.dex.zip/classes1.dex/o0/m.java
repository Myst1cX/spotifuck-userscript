package o0;

public abstract class m {
    public boolean a() {
        return false;
    }

    public boolean b(int[] iArr) {
        return false;
    }
}
