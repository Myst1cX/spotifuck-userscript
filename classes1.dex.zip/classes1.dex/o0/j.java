package o0;

public final class j extends n {
}
