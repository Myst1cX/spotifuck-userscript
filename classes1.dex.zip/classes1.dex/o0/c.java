package o0;

public abstract /* synthetic */ class c {
}
