package y;

import android.util.SparseIntArray;

public abstract class d {

    /* renamed from: a  reason: collision with root package name */
    public static final SparseIntArray f4951a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f4951a = sparseIntArray;
        sparseIntArray.append(98, 64);
        sparseIntArray.append(75, 65);
        sparseIntArray.append(84, 8);
        sparseIntArray.append(85, 9);
        sparseIntArray.append(87, 10);
        sparseIntArray.append(88, 11);
        sparseIntArray.append(94, 12);
        sparseIntArray.append(93, 13);
        sparseIntArray.append(65, 14);
        sparseIntArray.append(64, 15);
        sparseIntArray.append(60, 16);
        sparseIntArray.append(62, 52);
        sparseIntArray.append(61, 53);
        sparseIntArray.append(66, 2);
        sparseIntArray.append(68, 3);
        sparseIntArray.append(67, 4);
        sparseIntArray.append(103, 49);
        sparseIntArray.append(104, 50);
        sparseIntArray.append(72, 5);
        sparseIntArray.append(73, 6);
        sparseIntArray.append(74, 7);
        sparseIntArray.append(55, 67);
        sparseIntArray.append(0, 1);
        sparseIntArray.append(89, 17);
        sparseIntArray.append(90, 18);
        sparseIntArray.append(71, 19);
        sparseIntArray.append(70, 20);
        sparseIntArray.append(108, 21);
        sparseIntArray.append(111, 22);
        sparseIntArray.append(109, 23);
        sparseIntArray.append(106, 24);
        sparseIntArray.append(110, 25);
        sparseIntArray.append(107, 26);
        sparseIntArray.append(105, 55);
        sparseIntArray.append(112, 54);
        sparseIntArray.append(80, 29);
        sparseIntArray.append(95, 30);
        sparseIntArray.append(69, 44);
        sparseIntArray.append(82, 45);
        sparseIntArray.append(97, 46);
        sparseIntArray.append(81, 47);
        sparseIntArray.append(96, 48);
        sparseIntArray.append(58, 27);
        sparseIntArray.append(57, 28);
        sparseIntArray.append(99, 31);
        sparseIntArray.append(76, 32);
        sparseIntArray.append(101, 33);
        sparseIntArray.append(100, 34);
        sparseIntArray.append(102, 35);
        sparseIntArray.append(78, 36);
        sparseIntArray.append(77, 37);
        sparseIntArray.append(79, 38);
        sparseIntArray.append(83, 39);
        sparseIntArray.append(92, 40);
        sparseIntArray.append(86, 41);
        sparseIntArray.append(63, 42);
        sparseIntArray.append(59, 43);
        sparseIntArray.append(91, 51);
        sparseIntArray.append(114, 66);
    }
}
