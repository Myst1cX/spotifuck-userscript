package y;

public abstract class o {
}
