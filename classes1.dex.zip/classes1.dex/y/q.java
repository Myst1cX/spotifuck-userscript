package y;

public abstract class q {
}
