package Y;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public static final int[] f1000a = {16842755, 16842960, 16842961};

    /* renamed from: b  reason: collision with root package name */
    public static final int[] f1001b = {16842755, 16842961};
}
