package y;

public final class s {
}
