package y;

import java.util.Arrays;
import java.util.HashMap;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    public int f5037a;

    /* renamed from: b  reason: collision with root package name */
    public final l f5038b;

    /* renamed from: c  reason: collision with root package name */
    public final k f5039c;

    /* renamed from: d  reason: collision with root package name */
    public final j f5040d;
    public final m e;

    /* renamed from: f  reason: collision with root package name */
    public HashMap f5041f = new HashMap();

    public final void a(e eVar) {
        j jVar = this.f5040d;
        eVar.e = jVar.f5081h;
        eVar.f4986f = jVar.i;
        eVar.f4988g = jVar.f5084j;
        eVar.f4990h = jVar.f5086k;
        eVar.i = jVar.f5088l;
        eVar.f4993j = jVar.f5090m;
        eVar.f4995k = jVar.f5091n;
        eVar.f4997l = jVar.f5093o;
        eVar.f4999m = jVar.f5095p;
        eVar.f5000n = jVar.f5096q;
        eVar.f5002o = jVar.f5097r;
        eVar.f5008s = jVar.f5098s;
        eVar.f5009t = jVar.f5099t;
        eVar.f5010u = jVar.f5100u;
        eVar.f5011v = jVar.f5101v;
        eVar.leftMargin = jVar.f5048F;
        eVar.rightMargin = jVar.f5049G;
        eVar.topMargin = jVar.f5050H;
        eVar.bottomMargin = jVar.I;
        eVar.f4952A = jVar.f5059R;
        eVar.f4953B = jVar.f5058Q;
        eVar.f5013x = jVar.f5055N;
        eVar.f5015z = jVar.f5057P;
        eVar.f4956E = jVar.f5102w;
        eVar.f4957F = jVar.f5103x;
        eVar.f5004p = jVar.f5105z;
        eVar.f5006q = jVar.f5043A;
        eVar.f5007r = jVar.f5044B;
        eVar.f4958G = jVar.f5104y;
        eVar.f4970T = jVar.f5045C;
        eVar.f4971U = jVar.f5046D;
        eVar.I = jVar.f5061T;
        eVar.f4959H = jVar.f5062U;
        eVar.f4961K = jVar.f5064W;
        eVar.f4960J = jVar.f5063V;
        eVar.f4973W = jVar.f5089l0;
        eVar.f4974X = jVar.m0;
        eVar.f4962L = jVar.f5065X;
        eVar.f4963M = jVar.f5066Y;
        eVar.f4966P = jVar.f5067Z;
        eVar.f4967Q = jVar.f5069a0;
        eVar.f4964N = jVar.f5071b0;
        eVar.f4965O = jVar.f5073c0;
        eVar.f4968R = jVar.f5075d0;
        eVar.f4969S = jVar.f5076e0;
        eVar.f4972V = jVar.f5047E;
        eVar.f4981c = jVar.f5077f;
        eVar.f4977a = jVar.f5074d;
        eVar.f4979b = jVar.e;
        eVar.width = jVar.f5070b;
        eVar.height = jVar.f5072c;
        String str = jVar.f5087k0;
        if (str != null) {
            eVar.f4975Y = str;
        }
        eVar.f4976Z = jVar.f5094o0;
        eVar.setMarginStart(jVar.f5052K);
        eVar.setMarginEnd(jVar.f5051J);
        eVar.a();
    }

    public final Object clone() {
        i iVar = new i();
        j jVar = iVar.f5040d;
        jVar.getClass();
        j jVar2 = this.f5040d;
        jVar.f5068a = jVar2.f5068a;
        jVar.f5070b = jVar2.f5070b;
        jVar.f5072c = jVar2.f5072c;
        jVar.f5074d = jVar2.f5074d;
        jVar.e = jVar2.e;
        jVar.f5077f = jVar2.f5077f;
        jVar.f5079g = jVar2.f5079g;
        jVar.f5081h = jVar2.f5081h;
        jVar.i = jVar2.i;
        jVar.f5084j = jVar2.f5084j;
        jVar.f5086k = jVar2.f5086k;
        jVar.f5088l = jVar2.f5088l;
        jVar.f5090m = jVar2.f5090m;
        jVar.f5091n = jVar2.f5091n;
        jVar.f5093o = jVar2.f5093o;
        jVar.f5095p = jVar2.f5095p;
        jVar.f5096q = jVar2.f5096q;
        jVar.f5097r = jVar2.f5097r;
        jVar.f5098s = jVar2.f5098s;
        jVar.f5099t = jVar2.f5099t;
        jVar.f5100u = jVar2.f5100u;
        jVar.f5101v = jVar2.f5101v;
        jVar.f5102w = jVar2.f5102w;
        jVar.f5103x = jVar2.f5103x;
        jVar.f5104y = jVar2.f5104y;
        jVar.f5105z = jVar2.f5105z;
        jVar.f5043A = jVar2.f5043A;
        jVar.f5044B = jVar2.f5044B;
        jVar.f5045C = jVar2.f5045C;
        jVar.f5046D = jVar2.f5046D;
        jVar.f5047E = jVar2.f5047E;
        jVar.f5048F = jVar2.f5048F;
        jVar.f5049G = jVar2.f5049G;
        jVar.f5050H = jVar2.f5050H;
        jVar.I = jVar2.I;
        jVar.f5051J = jVar2.f5051J;
        jVar.f5052K = jVar2.f5052K;
        jVar.f5053L = jVar2.f5053L;
        jVar.f5054M = jVar2.f5054M;
        jVar.f5055N = jVar2.f5055N;
        jVar.f5056O = jVar2.f5056O;
        jVar.f5057P = jVar2.f5057P;
        jVar.f5058Q = jVar2.f5058Q;
        jVar.f5059R = jVar2.f5059R;
        jVar.f5060S = jVar2.f5060S;
        jVar.f5061T = jVar2.f5061T;
        jVar.f5062U = jVar2.f5062U;
        jVar.f5063V = jVar2.f5063V;
        jVar.f5064W = jVar2.f5064W;
        jVar.f5065X = jVar2.f5065X;
        jVar.f5066Y = jVar2.f5066Y;
        jVar.f5067Z = jVar2.f5067Z;
        jVar.f5069a0 = jVar2.f5069a0;
        jVar.f5071b0 = jVar2.f5071b0;
        jVar.f5073c0 = jVar2.f5073c0;
        jVar.f5075d0 = jVar2.f5075d0;
        jVar.f5076e0 = jVar2.f5076e0;
        jVar.f5078f0 = jVar2.f5078f0;
        jVar.f5080g0 = jVar2.f5080g0;
        jVar.f5082h0 = jVar2.f5082h0;
        jVar.f5087k0 = jVar2.f5087k0;
        int[] iArr = jVar2.f5083i0;
        if (iArr == null || jVar2.f5085j0 != null) {
            jVar.f5083i0 = null;
        } else {
            jVar.f5083i0 = Arrays.copyOf(iArr, iArr.length);
        }
        jVar.f5085j0 = jVar2.f5085j0;
        jVar.f5089l0 = jVar2.f5089l0;
        jVar.m0 = jVar2.m0;
        jVar.f5092n0 = jVar2.f5092n0;
        jVar.f5094o0 = jVar2.f5094o0;
        k kVar = iVar.f5039c;
        kVar.getClass();
        k kVar2 = this.f5039c;
        kVar2.getClass();
        kVar.f5107a = kVar2.f5107a;
        kVar.f5109c = kVar2.f5109c;
        kVar.e = kVar2.e;
        kVar.f5110d = kVar2.f5110d;
        l lVar = iVar.f5038b;
        l lVar2 = this.f5038b;
        lVar.f5114a = lVar2.f5114a;
        lVar.f5116c = lVar2.f5116c;
        lVar.f5117d = lVar2.f5117d;
        lVar.f5115b = lVar2.f5115b;
        m mVar = iVar.e;
        mVar.getClass();
        m mVar2 = this.e;
        mVar2.getClass();
        mVar.f5119a = mVar2.f5119a;
        mVar.f5120b = mVar2.f5120b;
        mVar.f5121c = mVar2.f5121c;
        mVar.f5122d = mVar2.f5122d;
        mVar.e = mVar2.e;
        mVar.f5123f = mVar2.f5123f;
        mVar.f5124g = mVar2.f5124g;
        mVar.f5125h = mVar2.f5125h;
        mVar.i = mVar2.i;
        mVar.f5126j = mVar2.f5126j;
        mVar.f5127k = mVar2.f5127k;
        mVar.f5128l = mVar2.f5128l;
        mVar.f5129m = mVar2.f5129m;
        iVar.f5037a = this.f5037a;
        return iVar;
    }

    /* JADX WARNING: type inference failed for: r0v0, types: [y.l, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v1, types: [y.k, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v2, types: [y.j, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r0v3, types: [y.m, java.lang.Object] */
    public i() {
        ? obj = new Object();
        obj.f5114a = 0;
        obj.f5115b = 0;
        obj.f5116c = 1.0f;
        obj.f5117d = Float.NaN;
        this.f5038b = obj;
        ? obj2 = new Object();
        obj2.f5107a = -1;
        obj2.f5108b = 0;
        obj2.f5109c = -1;
        obj2.f5110d = Float.NaN;
        obj2.e = Float.NaN;
        obj2.f5111f = Float.NaN;
        obj2.f5112g = -1;
        obj2.f5113h = null;
        obj2.i = -1;
        this.f5039c = obj2;
        ? obj3 = new Object();
        obj3.f5068a = false;
        obj3.f5074d = -1;
        obj3.e = -1;
        obj3.f5077f = -1.0f;
        obj3.f5079g = true;
        obj3.f5081h = -1;
        obj3.i = -1;
        obj3.f5084j = -1;
        obj3.f5086k = -1;
        obj3.f5088l = -1;
        obj3.f5090m = -1;
        obj3.f5091n = -1;
        obj3.f5093o = -1;
        obj3.f5095p = -1;
        obj3.f5096q = -1;
        obj3.f5097r = -1;
        obj3.f5098s = -1;
        obj3.f5099t = -1;
        obj3.f5100u = -1;
        obj3.f5101v = -1;
        obj3.f5102w = 0.5f;
        obj3.f5103x = 0.5f;
        obj3.f5104y = null;
        obj3.f5105z = -1;
        obj3.f5043A = 0;
        obj3.f5044B = 0.0f;
        obj3.f5045C = -1;
        obj3.f5046D = -1;
        obj3.f5047E = -1;
        obj3.f5048F = 0;
        obj3.f5049G = 0;
        obj3.f5050H = 0;
        obj3.I = 0;
        obj3.f5051J = 0;
        obj3.f5052K = 0;
        obj3.f5053L = 0;
        obj3.f5054M = Integer.MIN_VALUE;
        obj3.f5055N = Integer.MIN_VALUE;
        obj3.f5056O = Integer.MIN_VALUE;
        obj3.f5057P = Integer.MIN_VALUE;
        obj3.f5058Q = Integer.MIN_VALUE;
        obj3.f5059R = Integer.MIN_VALUE;
        obj3.f5060S = Integer.MIN_VALUE;
        obj3.f5061T = -1.0f;
        obj3.f5062U = -1.0f;
        obj3.f5063V = 0;
        obj3.f5064W = 0;
        obj3.f5065X = 0;
        obj3.f5066Y = 0;
        obj3.f5067Z = 0;
        obj3.f5069a0 = 0;
        obj3.f5071b0 = 0;
        obj3.f5073c0 = 0;
        obj3.f5075d0 = 1.0f;
        obj3.f5076e0 = 1.0f;
        obj3.f5078f0 = -1;
        obj3.f5080g0 = 0;
        obj3.f5082h0 = -1;
        obj3.f5089l0 = false;
        obj3.m0 = false;
        obj3.f5092n0 = true;
        obj3.f5094o0 = 0;
        this.f5040d = obj3;
        ? obj4 = new Object();
        obj4.f5119a = 0.0f;
        obj4.f5120b = 0.0f;
        obj4.f5121c = 0.0f;
        obj4.f5122d = 1.0f;
        obj4.e = 1.0f;
        obj4.f5123f = Float.NaN;
        obj4.f5124g = Float.NaN;
        obj4.f5125h = -1;
        obj4.i = 0.0f;
        obj4.f5126j = 0.0f;
        obj4.f5127k = 0.0f;
        obj4.f5128l = false;
        obj4.f5129m = 0.0f;
        this.e = obj4;
    }
}
