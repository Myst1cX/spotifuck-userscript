package T;

import android.widget.TextView;

public abstract class q {
    public static void a(TextView textView, int i, float f2) {
        textView.setLineHeight(i, f2);
    }
}
