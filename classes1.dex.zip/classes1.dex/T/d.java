package T;

import android.widget.EdgeEffect;

public abstract class d {
    public static void a(EdgeEffect edgeEffect, float f2, float f3) {
        edgeEffect.onPull(f2, f3);
    }
}
