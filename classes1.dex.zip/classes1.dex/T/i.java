package T;

import android.view.ViewGroup;

public abstract class i {
    public static boolean a(ViewGroup viewGroup) {
        return viewGroup.getClipToPadding();
    }
}
