package T;

import android.graphics.drawable.Drawable;
import android.widget.CompoundButton;

public abstract class c {
    public static Drawable a(CompoundButton compoundButton) {
        return compoundButton.getButtonDrawable();
    }
}
