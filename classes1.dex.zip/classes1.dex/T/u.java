package T;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

public interface u {
    void setSupportCompoundDrawablesTintList(ColorStateList colorStateList);

    void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode);
}
