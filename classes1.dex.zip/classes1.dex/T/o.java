package T;

import android.icu.text.DecimalFormatSymbols;
import java.util.Locale;

public abstract class o {
    public static DecimalFormatSymbols a(Locale locale) {
        return DecimalFormatSymbols.getInstance(locale);
    }
}
