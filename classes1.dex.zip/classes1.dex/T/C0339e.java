package t;

/* renamed from: t.e  reason: case insensitive filesystem */
public abstract /* synthetic */ class C0339e {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ int[] f4666a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};

    public static /* synthetic */ int a(int i) {
        if (i != 0) {
            return i - 1;
        }
        throw null;
    }

    public static /* synthetic */ int[] b(int i) {
        int[] iArr = new int[i];
        System.arraycopy(f4666a, 0, iArr, 0, i);
        return iArr;
    }
}
