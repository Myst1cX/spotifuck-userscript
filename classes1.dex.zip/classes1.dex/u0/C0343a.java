package u0;

import android.view.View;
import com.google.android.material.bottomappbar.BottomAppBar$Behavior;

/* renamed from: u0.a  reason: case insensitive filesystem */
public final class C0343a implements View.OnLayoutChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ BottomAppBar$Behavior f4681a;

    public final void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        this.f4681a.getClass();
        throw null;
    }

    public C0343a(BottomAppBar$Behavior bottomAppBar$Behavior) {
        this.f4681a = bottomAppBar$Behavior;
    }
}
