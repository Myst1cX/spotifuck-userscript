package U0;

import b1.b;
import b1.d;

public class a {
    public d a() {
        return new b();
    }
}
