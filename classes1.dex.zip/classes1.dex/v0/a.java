package V0;

public class a extends U0.a {
}
