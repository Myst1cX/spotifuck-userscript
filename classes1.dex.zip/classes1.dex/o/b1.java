package o;

import android.view.ViewGroup;

public final class b1 extends ViewGroup.MarginLayoutParams {

    /* renamed from: a  reason: collision with root package name */
    public int f4173a = 0;

    /* renamed from: b  reason: collision with root package name */
    public int f4174b;

    public b1(b1 b1Var) {
        super(b1Var);
        this.f4173a = b1Var.f4173a;
    }

    public b1(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
    }
}
