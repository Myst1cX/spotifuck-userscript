package o;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* renamed from: o.n0  reason: case insensitive filesystem */
public abstract class C0293n0 {

    /* renamed from: a  reason: collision with root package name */
    public static final boolean f4267a;

    /* renamed from: b  reason: collision with root package name */
    public static final Method f4268b;

    /* renamed from: c  reason: collision with root package name */
    public static final Field f4269c;

    /* renamed from: d  reason: collision with root package name */
    public static final Field f4270d;
    public static final Field e;

    /* renamed from: f  reason: collision with root package name */
    public static final Field f4271f;

    /* JADX WARNING: Removed duplicated region for block: B:43:0x0056  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x0063  */
    static {
        /*
            r0 = 1
            r1 = 0
            r2 = 0
            java.lang.String r3 = "android.graphics.Insets"
            java.lang.Class r3 = java.lang.Class.forName(r3)     // Catch:{ NoSuchMethodException -> 0x004e, ClassNotFoundException -> 0x004a, NoSuchFieldException -> 0x0046 }
            java.lang.Class<android.graphics.drawable.Drawable> r4 = android.graphics.drawable.Drawable.class
            java.lang.String r5 = "getOpticalInsets"
            java.lang.reflect.Method r4 = r4.getMethod(r5, r1)     // Catch:{ NoSuchMethodException -> 0x004e, ClassNotFoundException -> 0x004a, NoSuchFieldException -> 0x0046 }
            java.lang.String r5 = "left"
            java.lang.reflect.Field r5 = r3.getField(r5)     // Catch:{ NoSuchMethodException -> 0x0042, ClassNotFoundException -> 0x003e, NoSuchFieldException -> 0x003a }
            java.lang.String r6 = "top"
            java.lang.reflect.Field r6 = r3.getField(r6)     // Catch:{ NoSuchMethodException -> 0x0037, ClassNotFoundException -> 0x0034, NoSuchFieldException -> 0x0030 }
            java.lang.String r7 = "right"
            java.lang.reflect.Field r7 = r3.getField(r7)     // Catch:{ ClassNotFoundException | NoSuchFieldException | NoSuchMethodException -> 0x002d }
            java.lang.String r8 = "bottom"
            java.lang.reflect.Field r3 = r3.getField(r8)     // Catch:{ ClassNotFoundException | NoSuchFieldException | NoSuchMethodException -> 0x002b }
            r8 = 1
            goto L_0x0054
        L_0x002b:
            goto L_0x0052
        L_0x002d:
            r7 = r1
            goto L_0x0052
        L_0x0030:
            r6 = r1
        L_0x0032:
            r7 = r6
            goto L_0x0052
        L_0x0034:
            r6 = r1
            goto L_0x0032
        L_0x0037:
            r6 = r1
            goto L_0x0032
        L_0x003a:
            r5 = r1
        L_0x003c:
            r6 = r5
            goto L_0x0032
        L_0x003e:
            r5 = r1
        L_0x0040:
            r6 = r5
            goto L_0x0032
        L_0x0042:
            r5 = r1
        L_0x0044:
            r6 = r5
            goto L_0x0032
        L_0x0046:
            r4 = r1
            r5 = r4
            goto L_0x003c
        L_0x004a:
            r4 = r1
            r5 = r4
            goto L_0x0040
        L_0x004e:
            r4 = r1
            r5 = r4
            goto L_0x0044
        L_0x0052:
            r3 = r1
            r8 = 0
        L_0x0054:
            if (r8 == 0) goto L_0x0063
            f4268b = r4
            f4269c = r5
            f4270d = r6
            e = r7
            f4271f = r3
            f4267a = r0
            goto L_0x006f
        L_0x0063:
            f4268b = r1
            f4269c = r1
            f4270d = r1
            e = r1
            f4271f = r1
            f4267a = r2
        L_0x006f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: o.C0293n0.<clinit>():void");
    }
}
