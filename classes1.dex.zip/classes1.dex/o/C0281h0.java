package o;

import android.text.StaticLayout;
import android.widget.TextView;

/* renamed from: o.h0  reason: case insensitive filesystem */
public class C0281h0 {
    public void a(StaticLayout.Builder builder, TextView textView) {
    }

    public boolean b(TextView textView) {
        return ((Boolean) C0283i0.e(textView, "getHorizontallyScrolling", Boolean.FALSE)).booleanValue();
    }
}
