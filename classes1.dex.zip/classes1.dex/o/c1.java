package o;

public interface c1 {
}
