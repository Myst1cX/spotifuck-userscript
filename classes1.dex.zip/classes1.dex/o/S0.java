package o;

import android.widget.AdapterView;
import android.widget.HorizontalScrollView;

public abstract class S0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
}
