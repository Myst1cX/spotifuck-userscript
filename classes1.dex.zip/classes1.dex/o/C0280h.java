package o;

import n.C0188c;

/* renamed from: o.h  reason: case insensitive filesystem */
public final class C0280h extends C0188c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0286k f4203a;

    public C0280h(C0286k kVar) {
        this.f4203a = kVar;
    }
}
