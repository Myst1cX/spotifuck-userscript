package o;

/* renamed from: o.a0  reason: case insensitive filesystem */
public interface C0267a0 {
    void a(int i);

    void e(int i, float f2);

    void i(int i);
}
