package o;

import j0.C0160w;

/* renamed from: o.b0  reason: case insensitive filesystem */
public class C0269b0 extends C0160w {

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ C0273d0 f4172g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0269b0(C0273d0 d0Var) {
        super(d0Var);
        this.f4172g = d0Var;
    }

    public final void a(int i) {
        C0269b0.super.setFirstBaselineToTopHeight(i);
    }

    public final void i(int i) {
        C0269b0.super.setLastBaselineToBottomHeight(i);
    }
}
