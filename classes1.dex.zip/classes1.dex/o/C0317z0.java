package o;

import android.widget.LinearLayout;

/* renamed from: o.z0  reason: case insensitive filesystem */
public class C0317z0 extends LinearLayout.LayoutParams {
}
