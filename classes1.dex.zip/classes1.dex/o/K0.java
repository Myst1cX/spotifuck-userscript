package o;

import android.widget.PopupWindow;

public abstract class K0 {
    public static void a(PopupWindow popupWindow, boolean z2) {
        popupWindow.setTouchModal(z2);
    }
}
