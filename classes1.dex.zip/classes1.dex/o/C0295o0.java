package o;

import android.graphics.Insets;
import android.graphics.drawable.Drawable;

/* renamed from: o.o0  reason: case insensitive filesystem */
public abstract class C0295o0 {
    public static Insets a(Drawable drawable) {
        return drawable.getOpticalInsets();
    }
}
