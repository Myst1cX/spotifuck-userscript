package o;

/* renamed from: o.t  reason: case insensitive filesystem */
public final class C0304t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ C0306u f4297a;

    public C0304t(C0306u uVar) {
        this.f4297a = uVar;
    }
}
