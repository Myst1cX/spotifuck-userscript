package o;

/* renamed from: o.d  reason: case insensitive filesystem */
public interface C0272d {
}
