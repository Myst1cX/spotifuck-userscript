package o;

public interface l1 {
}
