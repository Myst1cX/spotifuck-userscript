package o;

/* renamed from: o.m0  reason: case insensitive filesystem */
public interface C0291m0 {
}
