package o;

/* renamed from: o.n  reason: case insensitive filesystem */
public interface C0292n {
}
