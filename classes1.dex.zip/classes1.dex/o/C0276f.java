package o;

import android.view.View;

/* renamed from: o.f  reason: case insensitive filesystem */
public final class C0276f extends View {
    public final int getWindowSystemUiVisibility() {
        return 0;
    }
}
