package o;

/* renamed from: o.l  reason: case insensitive filesystem */
public interface C0288l {
    boolean b();

    boolean c();
}
