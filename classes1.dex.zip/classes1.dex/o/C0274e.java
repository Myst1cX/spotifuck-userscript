package o;

import android.view.ViewGroup;

/* renamed from: o.e  reason: case insensitive filesystem */
public final class C0274e extends ViewGroup.MarginLayoutParams {
}
