package o;

import java.util.Locale;

public abstract class V {
    public static Locale a(String str) {
        return Locale.forLanguageTag(str);
    }
}
