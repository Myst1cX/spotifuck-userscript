package com.google.android.material.floatingactionbutton;

import android.content.Context;
import android.util.AttributeSet;

public class FloatingActionButton$Behavior extends FloatingActionButton$BaseBehavior<Object> {
    public FloatingActionButton$Behavior() {
    }

    public FloatingActionButton$Behavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
