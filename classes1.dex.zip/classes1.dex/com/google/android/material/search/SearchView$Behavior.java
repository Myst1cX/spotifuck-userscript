package com.google.android.material.search;

import A.c;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

public class SearchView$Behavior extends c {
    public SearchView$Behavior() {
    }

    public SearchView$Behavior(Context context, AttributeSet attributeSet) {
    }

    public final boolean d(CoordinatorLayout coordinatorLayout, View view, View view2) {
        throw new ClassCastException();
    }
}
