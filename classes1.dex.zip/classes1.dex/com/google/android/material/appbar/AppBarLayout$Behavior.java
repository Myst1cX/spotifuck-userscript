package com.google.android.material.appbar;

import android.content.Context;
import android.util.AttributeSet;

public class AppBarLayout$Behavior extends AppBarLayout$BaseBehavior<Object> {
    public AppBarLayout$Behavior() {
    }

    public AppBarLayout$Behavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
