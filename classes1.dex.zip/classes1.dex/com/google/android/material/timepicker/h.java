package com.google.android.material.timepicker;

import android.view.GestureDetector;
import android.view.MotionEvent;

public final class h extends GestureDetector.SimpleOnGestureListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ TimePickerView f2447a;

    public h(TimePickerView timePickerView) {
        this.f2447a = timePickerView;
    }

    public final boolean onDoubleTap(MotionEvent motionEvent) {
        int i = TimePickerView.f2437w;
        this.f2447a.getClass();
        return false;
    }
}
