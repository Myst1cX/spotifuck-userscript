package com.google.android.material.timepicker;

public final /* synthetic */ class f {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ TimePickerView f2445a;

    public /* synthetic */ f(TimePickerView timePickerView) {
        this.f2445a = timePickerView;
    }

    public final void a() {
        int i = TimePickerView.f2437w;
        this.f2445a.getClass();
    }
}
