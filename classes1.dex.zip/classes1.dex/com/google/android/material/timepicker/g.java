package com.google.android.material.timepicker;

import android.view.View;

public final class g implements View.OnClickListener {

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ TimePickerView f2446f;

    public final void onClick(View view) {
        int i = TimePickerView.f2437w;
        this.f2446f.getClass();
    }

    public g(TimePickerView timePickerView) {
        this.f2446f = timePickerView;
    }
}
