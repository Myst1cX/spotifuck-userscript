package com.google.android.material.datepicker;

import android.widget.TextView;
import j0.a0;

public final class w extends a0 {

    /* renamed from: t  reason: collision with root package name */
    public final TextView f2292t;

    public w(TextView textView) {
        super(textView);
        this.f2292t = textView;
    }
}
