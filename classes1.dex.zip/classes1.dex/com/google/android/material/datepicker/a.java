package com.google.android.material.datepicker;

import java.util.Calendar;

public final class a {

    /* renamed from: b  reason: collision with root package name */
    public static final /* synthetic */ int f2212b = 0;

    /* renamed from: a  reason: collision with root package name */
    public Long f2213a;

    static {
        n a2 = n.a(1900, 0);
        Calendar c2 = v.c((Calendar) null);
        c2.setTimeInMillis(a2.f2278f);
        v.a(c2).getTimeInMillis();
        n a3 = n.a(2100, 11);
        Calendar c3 = v.c((Calendar) null);
        c3.setTimeInMillis(a3.f2278f);
        v.a(c3).getTimeInMillis();
    }
}
