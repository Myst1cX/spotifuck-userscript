package com.google.android.material.datepicker;

import android.util.DisplayMetrics;
import j0.C0159v;

public final class t extends C0159v {
    public final float d(DisplayMetrics displayMetrics) {
        return 100.0f / ((float) displayMetrics.densityDpi);
    }
}
