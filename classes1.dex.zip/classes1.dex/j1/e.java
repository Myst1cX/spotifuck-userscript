package j1;

import java.lang.ref.WeakReference;

public final class e extends WeakReference {

    /* renamed from: a  reason: collision with root package name */
    public final Object f3548a;

    public e(f fVar, Object obj) {
        super(fVar);
        this.f3548a = obj;
    }
}
