package l0;

import android.content.Context;
import java.util.List;

/* renamed from: l0.b  reason: case insensitive filesystem */
public interface C0173b {
    List a();

    Object b(Context context);
}
